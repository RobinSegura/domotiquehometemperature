package serveur.mobile.metier;

/**
 * Created by dv on 03/10/2016.
 */
public interface IMetier {
    public double getTemperature(String nomCapteur);
}
